library(testthat)
library(cTMed)

test_check("cTMed")
