# cTMed 1.0.1.9000

* Latest development version.
* Added standardized effects.

# cTMed 1.0.1

* Minor edits to documentation.

# cTMed 1.0.0

* Initial CRAN submission.
