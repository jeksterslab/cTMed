# cTMed 1.0.2.9000

* Latest development version.

# cTMed 1.0.2

## Patch

* Added standardized total, direct, and indirect effects.

# cTMed 1.0.1

## Patch

* Minor edits to documentation.

# cTMed 1.0.0

* Initial CRAN submission.
